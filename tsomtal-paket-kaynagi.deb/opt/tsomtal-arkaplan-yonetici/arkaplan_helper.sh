#!/bin/bash

# ============================================
# TSOMTAL Arkaplan Yöneticisi - Helper (Sürüm 3)
# dconf öncelik sırası düzeltildi.
# ============================================

if [ "$(id -u)" -ne 0 ]; then
  exit 126 
fi

ACTION="$1"
FILE_URI="$2"

DCONF_DIR="/etc/dconf/db/local.d"
LOCKS_DIR="${DCONF_DIR}/locks"
PROFILE_FILE="/etc/dconf/profile/user"

# Gerekli dizinleri oluştur
mkdir -p "$LOCKS_DIR"

# =================================================================
# DÜZELTME BURADA: dconf profilini YENİDEN OLUŞTURUYORUZ.
# 'local' veritabanını en yüksek öncelikli sistem veritabanı 
# (user-db'den sonraki ilk) olarak ayarlıyoruz.
# Bu, bizim ayarlarımızın Pardus'un varsayılanlarını ezmesini sağlar.
# =================================================================
cat > "$PROFILE_FILE" << EOF
user-db:user
system-db:local
system-db:pardus
system-db:gdm
EOF

# --- İŞLEM SEÇİMİ ---

case "$ACTION" in
  lock)
    if [ -z "$FILE_URI" ]; then
      exit 1
    fi

    # Arkaplan Ayar Dosyasını Oluştur
    printf "[org/gnome/desktop/background]\npicture-uri='%s'\npicture-uri-dark='%s'\npicture-options='zoom'\n" "$FILE_URI" "$FILE_URI" > "${DCONF_DIR}/00-arkaplan-ayari"

    # Kilit Dosyasını Oluştur
    cat > "${LOCKS_DIR}/arkaplan-kilidi" << EOF
/org/gnome/desktop/background/picture-uri
/org/gnome/desktop/background/picture-uri-dark
/org/gnome/desktop/background/picture-options
EOF

    dconf update
    ;;

  unlock)
    # Kilidi kaldırırken, ayar dosyamızı da kaldıralım
    rm -f "${DCONF_DIR}/00-arkaplan-ayari"
    rm -f "${LOCKS_DIR}/arkaplan-kilidi"
    dconf update
    ;;
  *)
    exit 2
    ;;
esac

exit 0
